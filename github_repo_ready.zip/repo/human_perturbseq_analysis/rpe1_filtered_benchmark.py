import numpy as np
import pacmap, umap
from sklearn.metrics import roc_auc_score
from scipy.stats import wilcoxon
import warnings
warnings.filterwarnings('ignore')

pcs = np.load('rpe1_pcs_filtered.npy')
gold_idx = np.load('rpe1_gold_idx_filtered.npy')
labels = np.load('rpe1_gold_labels_filtered.npy')
iu_i = np.load('rpe1_gold_iu_i_filtered.npy')
iu_j = np.load('rpe1_gold_iu_j_filtered.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

seeds = [1, 7, 13, 42, 55, 77, 99, 123]
umap_aucs, pacmap_aucs = [], []
for seed in seeds:
    r = umap.UMAP(n_neighbors=20, min_dist=0.05, metric='cosine', random_state=seed)
    umap_aucs.append(auc_for(r.fit_transform(pcs)))
    e = pacmap.PaCMAP(n_components=2, n_neighbors=10, MN_ratio=0.5, FP_ratio=2.0, random_state=seed, verbose=False)
    pacmap_aucs.append(auc_for(e.fit_transform(pcs, init="pca")))
    print(f"seed={seed}: UMAP={umap_aucs[-1]:.4f}  PaCMAP={pacmap_aucs[-1]:.4f}")

stat, p = wilcoxon(umap_aucs, pacmap_aucs)
print(f"\nUMAP mean: {np.mean(umap_aucs):.4f} ± {np.std(umap_aucs)/np.sqrt(8):.4f}")
print(f"PaCMAP mean: {np.mean(pacmap_aucs):.4f} ± {np.std(pacmap_aucs)/np.sqrt(8):.4f}")
print(f"Wilcoxon p-value: {p:.4f}")
