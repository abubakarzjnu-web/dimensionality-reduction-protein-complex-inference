import anndata as ad
import pandas as pd
import numpy as np
import re

a = ad.read_h5ad('../data/replogle2022/K562_essential_normalized_bulk_01.h5ad')
print("Shape:", a.shape)

# Parse target gene symbol from obs_names like "10023_ZC3H18_P1P2_ENSG00000158545"
def parse_target(name):
    parts = name.split('_')
    # gene symbol is typically parts[1], but check for non-targeting controls
    if 'non-targeting' in name.lower() or 'NTC' in name:
        return 'CONTROL'
    return parts[1] if len(parts) > 1 else name

targets = [parse_target(n) for n in a.obs_names]
print("Sample targets:", targets[:10])
print("Unique targets:", len(set(targets)))
print("Control count:", targets.count('CONTROL'))

gene_symbols = a.var['gene_name'].values
X = a.X

df = pd.DataFrame(X, columns=gene_symbols)
df['target'] = targets
df = df[df['target'] != 'CONTROL']

consensus = df.groupby('target').mean()
print("\nConsensus matrix (target genes x measured genes):", consensus.shape)

# check for duplicate column names (gene_symbols) and handle
dup_cols = consensus.columns[consensus.columns.duplicated()].unique()
print("Duplicate gene-symbol columns:", len(dup_cols))
consensus = consensus.loc[:, ~consensus.columns.duplicated()]
print("After dedup:", consensus.shape)

consensus.to_csv('perturbseq_expression_matrix.csv')
print("Saved.")
