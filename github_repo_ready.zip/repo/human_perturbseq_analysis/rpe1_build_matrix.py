import anndata as ad
import pandas as pd
import numpy as np

a = ad.read_h5ad('../data/replogle2022/rpe1_normalized_bulk_01.h5ad')
print("Shape:", a.shape)

def parse_target(name):
    parts = name.split('_')
    if 'non-targeting' in name.lower() or 'NTC' in name:
        return 'CONTROL'
    return parts[1] if len(parts) > 1 else name

targets = [parse_target(n) for n in a.obs_names]
print("Unique targets:", len(set(targets)))
print("Control count:", targets.count('CONTROL'))

gene_symbols = a.var['gene_name'].values
X = a.X
df = pd.DataFrame(X, columns=gene_symbols)
df['target'] = targets
df = df[df['target'] != 'CONTROL']

consensus = df.groupby('target').mean()
dup_cols = consensus.columns[consensus.columns.duplicated()].unique()
consensus = consensus.loc[:, ~consensus.columns.duplicated()]
print("Consensus matrix:", consensus.shape)

consensus.to_csv('rpe1_expression_matrix.csv')
print("Saved.")
