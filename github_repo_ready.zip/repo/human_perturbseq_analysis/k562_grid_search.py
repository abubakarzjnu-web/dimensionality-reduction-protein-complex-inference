import numpy as np
import pandas as pd
import pacmap, umap
from sklearn.metrics import roc_auc_score
import time

pcs = np.load('perturbseq_pcs.npy')
gold_idx = np.load('perturbseq_gold_idx.npy')
labels = np.load('perturbseq_gold_labels.npy')
iu_i = np.load('perturbseq_gold_iu_i.npy')
iu_j = np.load('perturbseq_gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

results = []
t0 = time.time()

print("=== UMAP grid ===")
for nn in [5, 10, 15, 20]:
    for md in [0.05, 0.1, 0.3]:
        r = umap.UMAP(n_neighbors=nn, min_dist=md, metric='cosine', random_state=42)
        Y = r.fit_transform(pcs)
        auc = auc_for(Y)
        results.append({'method':'UMAP', 'n_neighbors': nn, 'param2': md, 'AUC': auc})
        print(f"UMAP nn={nn}, min_dist={md} -> AUC={auc:.4f} ({time.time()-t0:.0f}s)")

print("\n=== PaCMAP grid ===")
for nn in [5, 10, 15, 20]:
    for mn in [0.5, 1.0, 2.0]:
        e = pacmap.PaCMAP(n_components=2, n_neighbors=nn, MN_ratio=mn, FP_ratio=2.0, random_state=42, verbose=False)
        Y = e.fit_transform(pcs, init="pca")
        auc = auc_for(Y)
        results.append({'method':'PaCMAP', 'n_neighbors': nn, 'param2': mn, 'AUC': auc})
        print(f"PaCMAP nn={nn}, MN={mn} -> AUC={auc:.4f} ({time.time()-t0:.0f}s)")

df = pd.DataFrame(results)
df.to_csv('perturbseq_grid_results.csv', index=False)

print("\n=== SUMMARY ===")
for m in ['UMAP','PaCMAP']:
    sub = df[df.method==m]
    print(f"{m}: best={sub.AUC.max():.4f}  mean={sub.AUC.mean():.4f}  worst={sub.AUC.min():.4f}")
