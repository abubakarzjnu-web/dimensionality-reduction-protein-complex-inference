import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

expr = pd.read_csv('rpe1_expression_matrix_filtered.csv', index_col=0)
print("Filtered expression matrix:", expr.shape, "NaN:", expr.isna().sum().sum())
X = expr.values
Xscaled = StandardScaler().fit_transform(X)
pcs = PCA(n_components=100, random_state=42).fit_transform(Xscaled)
np.save('rpe1_pcs_filtered.npy', pcs)
np.save('rpe1_gene_names_filtered.npy', expr.index.values)
print("PCA done:", pcs.shape)

corum = pd.read_csv('../data/corum/allComplexes.txt', sep='\t')
corum_human = corum[corum['Organism'] == 'Human']
genes_available = set(expr.index)

ppi_list = []
for _, row in corum_human.iterrows():
    if pd.isna(row['subunits(Gene name)']):
        continue
    gl = [g.strip() for g in row['subunits(Gene name)'].split(';')]
    for g in gl:
        if g in genes_available:
            ppi_list.append({'sys_gene': g, 'Complex': row['ComplexName']})
ppi_list = pd.DataFrame(ppi_list).drop_duplicates()
genes_list = sorted(ppi_list['sys_gene'].unique())
print("Gold-standard genes:", len(genes_list))

complex_sets = [set(ppi_list[ppi_list['sys_gene']==g]['Complex']) for g in genes_list]
n = len(genes_list)
same = np.zeros((n,n), dtype=bool)
for i in range(n):
    for j in range(i+1,n):
        if complex_sets[i] & complex_sets[j]:
            same[i,j] = True
iu = np.triu_indices(n, k=1)
labels = same[iu]
print("Total pairs:", len(labels), "positives:", labels.sum())

strain_idx = {g:i for i,g in enumerate(expr.index)}
gold_idx = np.array([strain_idx[g] for g in genes_list])
np.save('rpe1_gold_idx_filtered.npy', gold_idx)
np.save('rpe1_gold_labels_filtered.npy', labels)
np.save('rpe1_gold_iu_i_filtered.npy', iu[0])
np.save('rpe1_gold_iu_j_filtered.npy', iu[1])
print("Done.")
