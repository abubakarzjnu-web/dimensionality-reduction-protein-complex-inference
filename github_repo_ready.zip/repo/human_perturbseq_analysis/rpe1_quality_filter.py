import anndata as ad
import pandas as pd
import numpy as np

a_rpe1 = ad.read_h5ad('../data/replogle2022/rpe1_normalized_bulk_01.h5ad')
print("Original RPE1 genes:", a_rpe1.n_obs)

# Filter to high-confidence perturbations only (num_cells_filtered >= 100, similar to K562 median)
high_conf = a_rpe1[a_rpe1.obs['num_cells_filtered'] >= 100]
print("High-confidence (>=100 cells) RPE1 genes:", high_conf.n_obs)
print("Median cells in filtered set:", high_conf.obs['num_cells_filtered'].median())

def parse_target(name):
    parts = name.split('_')
    if 'non-targeting' in name.lower() or 'NTC' in name:
        return 'CONTROL'
    return parts[1] if len(parts) > 1 else name

targets = [parse_target(n) for n in high_conf.obs_names]
gene_symbols = high_conf.var['gene_name'].values
X = high_conf.X
df = pd.DataFrame(X, columns=gene_symbols)
df['target'] = targets
df = df[df['target'] != 'CONTROL']
consensus = df.groupby('target').mean()
dup_cols = consensus.columns[consensus.columns.duplicated()].unique()
consensus = consensus.loc[:, ~consensus.columns.duplicated()]

# drop inf columns as before
X_check = consensus.values
inf_cols = np.unique(np.where(np.isinf(X_check))[1])
if len(inf_cols) > 0:
    consensus = consensus.drop(columns=consensus.columns[inf_cols])

print("Filtered consensus matrix:", consensus.shape)
consensus.to_csv('rpe1_expression_matrix_filtered.csv')
