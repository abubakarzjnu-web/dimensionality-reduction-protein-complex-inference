import numpy as np
import pacmap, umap
from sklearn.metrics import roc_auc_score
import warnings
warnings.filterwarnings('ignore')

pcs = np.load('rpe1_pcs.npy')
gold_idx = np.load('rpe1_gold_idx.npy')
labels = np.load('rpe1_gold_labels.npy')
iu_i = np.load('rpe1_gold_iu_i.npy')
iu_j = np.load('rpe1_gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

print("=== UMAP best config (nn=20, min_dist=0.05) across seeds ===")
umap_aucs = []
for seed in [1, 7, 42, 99]:
    r = umap.UMAP(n_neighbors=20, min_dist=0.05, metric='cosine', random_state=seed)
    Y = r.fit_transform(pcs)
    auc = auc_for(Y)
    umap_aucs.append(auc)
    print(f"seed={seed}: AUC={auc:.4f}")
print(f"UMAP mean±std: {np.mean(umap_aucs):.4f} ± {np.std(umap_aucs):.4f}")

print("\n=== PaCMAP best config (nn=10, MN=0.5) across seeds ===")
pacmap_aucs = []
for seed in [1, 7, 42, 99]:
    e = pacmap.PaCMAP(n_components=2, n_neighbors=10, MN_ratio=0.5, FP_ratio=2.0, random_state=seed, verbose=False)
    Y = e.fit_transform(pcs, init="pca")
    auc = auc_for(Y)
    pacmap_aucs.append(auc)
    print(f"seed={seed}: AUC={auc:.4f}")
print(f"PaCMAP mean±std: {np.mean(pacmap_aucs):.4f} ± {np.std(pacmap_aucs):.4f}")
