import numpy as np
import umap
from sklearn.metrics import roc_auc_score
from scipy.stats import wilcoxon
import warnings, time
warnings.filterwarnings('ignore')

pcs = np.load('pcs.npy')
gold_idx = np.load('gold_genes_idx.npy')
labels = np.load('gold_labels.npy')
iu_i = np.load('gold_iu_i.npy')
iu_j = np.load('gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

t0 = time.time()
seeds = [1, 7, 13, 42, 55, 77, 99, 123]
lc_values = [1.0, 2.0, 5.0, 10.0, 20.0, 30.0]

results = {}
for lc in lc_values:
    aucs = []
    for seed in seeds:
        r = umap.UMAP(n_neighbors=15, min_dist=0.05, metric='cosine', local_connectivity=lc, random_state=seed)
        emb = r.fit_transform(pcs)
        aucs.append(auc_for(emb))
    results[lc] = aucs
    print(f"local_connectivity={lc}: mean={np.mean(aucs):.4f} ± {np.std(aucs)/np.sqrt(len(aucs)):.4f}  ({time.time()-t0:.0f}s)")

# statistical test: lc=1 vs lc=30
stat, p = wilcoxon(results[1.0], results[30.0])
print(f"\nWilcoxon test (lc=1.0 vs lc=30.0): p={p:.4f}")
print(f"lc=1.0 mean: {np.mean(results[1.0]):.4f}")
print(f"lc=30.0 mean: {np.mean(results[30.0]):.4f}")
print(f"Original PaCMAP mean (reference): 0.668")

import json
with open('local_connectivity_results.json','w') as f:
    json.dump({str(k):v for k,v in results.items()}, f)
