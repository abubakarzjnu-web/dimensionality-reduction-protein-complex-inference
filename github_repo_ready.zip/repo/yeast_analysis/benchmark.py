import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from itertools import combinations

pacmap_df = pd.read_csv('pacmap_embedding.csv').rename(columns={'strain_sys':'sys_gene'})
umap_df = pd.read_csv('umap_from_paper.csv').drop_duplicates(subset='strain_sys', keep='first')
umap_df = umap_df.rename(columns={'strain_sys':'sys_gene'})

consensus = pd.read_csv('yeast_umap/useful_files/Kemmeren_Consensus.csv')
ppi = consensus[['complex_name','complex_members_sys']].copy()
ppi_list = []
for _, row in ppi.iterrows():
    genes = [g.strip() for g in row['complex_members_sys'].split(';')]
    for g in genes:
        ppi_list.append({'sys_gene': g, 'Complex': row['complex_name']})
ppi_list = pd.DataFrame(ppi_list)
print("PPI gene-complex rows:", ppi_list.shape)
print("Unique genes in curated complexes:", ppi_list['sys_gene'].nunique())

def build_eval(emb_df, coord_cols, label):
    merged = ppi_list.merge(emb_df, on='sys_gene', how='inner')
    genes_present = merged['sys_gene'].unique()
    print(f"[{label}] genes from ppi_list present in embedding: {len(genes_present)}")

    coords = merged.set_index('sys_gene')[coord_cols]
    complexes = merged.set_index('sys_gene')['Complex']

    # handle genes with multiple complex rows: keep all rows (as script does, via left_join duplication)
    sub = merged[['sys_gene', 'Complex'] + coord_cols].drop_duplicates()

    pairs = []
    genes_list = sub['sys_gene'].unique()
    gene_to_rows = {g: sub[sub['sys_gene']==g] for g in genes_list}

    rows = []
    for g1, g2 in combinations(genes_list, 2):
        r1 = gene_to_rows[g1]
        r2 = gene_to_rows[g2]
        c1 = coords.loc[g1].iloc[0] if isinstance(coords.loc[g1], pd.DataFrame) else coords.loc[g1]
        c2 = coords.loc[g2].iloc[0] if isinstance(coords.loc[g2], pd.DataFrame) else coords.loc[g2]
        dist = np.linalg.norm(np.array(c1, dtype=float) - np.array(c2, dtype=float))
        same_complex = bool(set(r1['Complex']) & set(r2['Complex']))
        rows.append((g1, g2, dist, same_complex))

    res = pd.DataFrame(rows, columns=['gene1','gene2','dist','pair_in_complex'])
    return res

res_umap = build_eval(umap_df, ['umap_1','umap_2'], 'UMAP')
res_pacmap = build_eval(pacmap_df, ['pacmap_1','pacmap_2'], 'PaCMAP')

auc_umap = roc_auc_score(res_umap['pair_in_complex'], -res_umap['dist'])
auc_pacmap = roc_auc_score(res_pacmap['pair_in_complex'], -res_pacmap['dist'])

print("\n=== FAITHFUL REPLICATION OF PAPER'S METHODOLOGY ===")
print(f"Total pairs evaluated (UMAP):   {len(res_umap)}  | positives: {res_umap['pair_in_complex'].sum()}")
print(f"Total pairs evaluated (PaCMAP): {len(res_pacmap)}  | positives: {res_pacmap['pair_in_complex'].sum()}")
print(f"AUC UMAP (paper's own coordinates):  {auc_umap:.4f}")
print(f"AUC PaCMAP (this analysis):          {auc_pacmap:.4f}")
print(f"Paper's reported UMAP AUC (Fig 2a):  0.84  (note: likely used larger/different consensus interaction set than the 518-row file shipped in repo)")

res_umap.to_csv('res_umap_pairs.csv', index=False)
res_pacmap.to_csv('res_pacmap_pairs.csv', index=False)
