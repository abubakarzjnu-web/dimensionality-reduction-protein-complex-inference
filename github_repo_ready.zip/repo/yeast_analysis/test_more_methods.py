import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.manifold import TSNE
import warnings, time
warnings.filterwarnings('ignore')

pcs = np.load('pcs.npy')
gold_idx = np.load('gold_genes_idx.npy')
labels = np.load('gold_labels.npy')
iu_i = np.load('gold_iu_i.npy')
iu_j = np.load('gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

t0 = time.time()

# t-SNE (local-structure family, like UMAP)
print("=== t-SNE ===")
tsne_results = []
for perp in [10, 30, 50]:
    for seed in [1, 42, 99]:
        emb = TSNE(n_components=2, perplexity=perp, random_state=seed, init='pca').fit_transform(pcs)
        auc = auc_for(emb)
        tsne_results.append(auc)
        print(f"perplexity={perp}, seed={seed}: AUC={auc:.4f} ({time.time()-t0:.0f}s)")
print(f"t-SNE mean±std: {np.mean(tsne_results):.4f} ± {np.std(tsne_results):.4f}\n")

# TriMAP (global-structure family, like PaCMAP)
print("=== TriMAP ===")
import trimap
trimap_results = []
for n_in in [10, 15, 20]:
    for seed in [1, 42, 99]:
        emb = trimap.TRIMAP(n_dims=2, n_inliers=n_in, verbose=False).fit_transform(pcs.astype(np.float64))
        auc = auc_for(emb)
        trimap_results.append(auc)
        print(f"n_inliers={n_in}, seed={seed}: AUC={auc:.4f} ({time.time()-t0:.0f}s)")
print(f"TriMAP mean±std: {np.mean(trimap_results):.4f} ± {np.std(trimap_results):.4f}\n")

import json
with open('extra_methods_yeast.json','w') as f:
    json.dump({'tsne': tsne_results, 'trimap': trimap_results}, f)
