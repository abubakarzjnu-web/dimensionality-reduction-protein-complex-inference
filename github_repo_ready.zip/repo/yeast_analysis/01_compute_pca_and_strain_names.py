import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

expr = pd.read_csv('expression_matrix.csv', index_col=0)
X = expr.T
Xlog = np.log1p(X.values)
Xscaled = StandardScaler().fit_transform(Xlog)
pcs = PCA(n_components=100, random_state=42).fit_transform(Xscaled)
np.save('pcs.npy', pcs)
np.save('strain_names.npy', X.index.values)
print("Saved PCs:", pcs.shape)
