import pandas as pd
import numpy as np

strains = np.load('strain_names.npy', allow_pickle=True)
strain_idx = {s:i for i,s in enumerate(strains)}

consensus = pd.read_csv('yeast_umap/useful_files/Kemmeren_Consensus.csv')
ppi_list = []
for _, row in consensus.iterrows():
    genes = [g.strip() for g in row['complex_members_sys'].split(';')]
    for g in genes:
        if g in strain_idx:
            ppi_list.append({'sys_gene': g, 'Complex': row['complex_name']})
ppi_list = pd.DataFrame(ppi_list)

genes_list = sorted(ppi_list['sys_gene'].unique())
gene_pos = {g:i for i,g in enumerate(genes_list)}
n = len(genes_list)
print("Genes in gold standard, present in dataset:", n)

# complex sets per gene
complex_sets = [set(ppi_list[ppi_list['sys_gene']==g]['Complex']) for g in genes_list]

# same-complex label matrix (upper triangle)
same = np.zeros((n,n), dtype=bool)
for i in range(n):
    for j in range(i+1,n):
        if complex_sets[i] & complex_sets[j]:
            same[i,j] = True

iu = np.triu_indices(n, k=1)
labels = same[iu]
print("Total pairs:", len(labels), "positives:", labels.sum())

np.save('gold_genes_idx.npy', np.array([strain_idx[g] for g in genes_list]))
np.save('gold_labels.npy', labels)
np.save('gold_iu_i.npy', iu[0])
np.save('gold_iu_j.npy', iu[1])
print("Gold standard prepped.")
