#!/usr/bin/env Rscript
# extract_yeast_expression_matrix.R
#
# First step of the yeast_analysis pipeline. Extracts the raw expression
# matrix and strain names from the Monocle3 cell_data_set object shipped in
# the yeast_umap repository (github.com/cole-trapnell-lab/yeast_umap), and
# writes them out as a plain CSV and a NumPy .npy file for use by the
# downstream Python scripts in this directory.
#
# This script deliberately does NOT require the `monocle3` package to be
# installed: it accesses the S4 object's slots directly via low-level
# `attr()` calls, since monocle3's Bioconductor dependency chain is heavy
# and unnecessary for this simple data-extraction step.
#
# Usage:
#   Rscript extract_yeast_expression_matrix.R \
#       yeast_umap/useful_files/yeast_del_strain_monocle3_cds.RDS \
#       expression_matrix.csv
#
# Requires only base R plus the `Matrix` package (a base R dependency,
# almost always already installed).

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) {
  stop("Usage: Rscript extract_yeast_expression_matrix.R <input.RDS> <output.csv>")
}
input_rds <- args[1]
output_csv <- args[2]

suppressMessages(library(Matrix))

x <- readRDS(input_rds)

# Navigate the cell_data_set S4 object's slots directly (no monocle3 needed)
assays_slot <- attr(x, "assays")
env <- attr(assays_slot, ".xData")
data_sl <- get("data", envir = env)
mat <- attr(data_sl, "listData")[[1]]   # sparse counts matrix, genes x strains

dense <- as.matrix(mat)
df <- as.data.frame(dense)
df <- cbind(gene = rownames(dense), df)

write.csv(df, output_csv, row.names = FALSE)
cat("Wrote expression matrix:", dim(dense)[1], "genes x", dim(dense)[2], "strains ->", output_csv, "\n")
cat("Next step: run 01_compute_pca_and_strain_names.py to derive pcs.npy and strain_names.npy.\n")
