import pandas as pd
import numpy as np

strains = np.load('strain_names.npy', allow_pickle=True)
strain_idx = {s:i for i,s in enumerate(strains)}
print("Total strains in yeast dataset:", len(strains))

# === Source 1: original Kemmeren_Consensus.csv (complex-based pairs) ===
consensus = pd.read_csv('yeast_umap/useful_files/Kemmeren_Consensus.csv')
pairs_1 = set()
for members in consensus['complex_members_sys'].dropna():
    genes = [g.strip() for g in members.split(';')]
    genes = [g for g in genes if g in strain_idx]
    for i in range(len(genes)):
        for j in range(i+1, len(genes)):
            pairs_1.add(tuple(sorted([genes[i], genes[j]])))
print("Source 1 (Kemmeren_Consensus) pairs:", len(pairs_1))

# === Source 2: Data File S12 (Costanzo/Benschop/Baryshnikova complex standard) ===
s12 = pd.read_excel('../data/costanzo2016/Data_File_S12_Protein_complex_standard.xlsx')
pairs_2 = set()
for members in s12['ORFs annotated to complex '].dropna():
    genes = [g.strip() for g in str(members).split(';')]
    genes = [g for g in genes if g in strain_idx]
    for i in range(len(genes)):
        for j in range(i+1, len(genes)):
            pairs_2.add(tuple(sorted([genes[i], genes[j]])))
print("Source 2 (Data File S12) pairs:", len(pairs_2))

# === Source 3: STRING high-confidence interactions ===
string_df = pd.read_csv('4932_protein_links_v12_0_txt', sep=' ')
string_df = string_df[string_df['combined_score'] >= 700]
print("STRING high-confidence (score>=700) rows:", len(string_df))

def clean_orf(x):
    return x.split('.')[-1]  # strip "4932." prefix

string_df['p1'] = string_df['protein1'].apply(clean_orf)
string_df['p2'] = string_df['protein2'].apply(clean_orf)
string_df = string_df[string_df['p1'].isin(strain_idx) & string_df['p2'].isin(strain_idx)]
pairs_3 = set(tuple(sorted([r.p1, r.p2])) for r in string_df.itertuples())
print("Source 3 (STRING) pairs (filtered to our gene set):", len(pairs_3))

# === Union of all three ===
all_pairs = pairs_1 | pairs_2 | pairs_3
print("\nTotal UNION of positive pairs (all 3 sources):", len(all_pairs))

import pickle
with open('expanded_gold_pairs.pkl','wb') as f:
    pickle.dump(all_pairs, f)
