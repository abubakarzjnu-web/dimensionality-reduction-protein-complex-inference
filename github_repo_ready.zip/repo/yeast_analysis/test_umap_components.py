import numpy as np
import umap
from sklearn.metrics import roc_auc_score
import warnings, time
warnings.filterwarnings('ignore')

pcs = np.load('pcs.npy')
gold_idx = np.load('gold_genes_idx.npy')
labels = np.load('gold_labels.npy')
iu_i = np.load('gold_iu_i.npy')
iu_j = np.load('gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

t0 = time.time()

print("=== Isolating local_connectivity (adaptive local-density normalization) ===")
for lc in [1.0, 3.0, 10.0, 30.0]:
    aucs = []
    for seed in [1, 42, 99]:
        r = umap.UMAP(n_neighbors=15, min_dist=0.05, metric='cosine', local_connectivity=lc, random_state=seed)
        emb = r.fit_transform(pcs)
        aucs.append(auc_for(emb))
    print(f"local_connectivity={lc}: mean={np.mean(aucs):.4f} ± {np.std(aucs):.4f}  ({time.time()-t0:.0f}s)")

print("\n=== Isolating negative_sample_rate (repulsion / negative-sampling strategy) ===")
for nsr in [1, 5, 15, 50]:
    aucs = []
    for seed in [1, 42, 99]:
        r = umap.UMAP(n_neighbors=15, min_dist=0.05, metric='cosine', negative_sample_rate=nsr, random_state=seed)
        emb = r.fit_transform(pcs)
        aucs.append(auc_for(emb))
    print(f"negative_sample_rate={nsr}: mean={np.mean(aucs):.4f} ± {np.std(aucs):.4f}  ({time.time()-t0:.0f}s)")

print("\n=== Isolating repulsion_strength ===")
for rs in [0.3, 1.0, 3.0, 10.0]:
    aucs = []
    for seed in [1, 42, 99]:
        r = umap.UMAP(n_neighbors=15, min_dist=0.05, metric='cosine', repulsion_strength=rs, random_state=seed)
        emb = r.fit_transform(pcs)
        aucs.append(auc_for(emb))
    print(f"repulsion_strength={rs}: mean={np.mean(aucs):.4f} ± {np.std(aucs):.4f}  ({time.time()-t0:.0f}s)")
