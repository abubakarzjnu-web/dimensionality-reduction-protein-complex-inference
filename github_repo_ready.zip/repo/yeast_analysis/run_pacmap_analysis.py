import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import pacmap
from sklearn.metrics import roc_auc_score, roc_curve

np.random.seed(42)

# 1. Load expression matrix (genes x strains) -> transpose to strains x genes
print("Loading expression matrix...")
expr = pd.read_csv('expression_matrix.csv', index_col=0)  # 6170 genes x 1484 strains
X = expr.T  # 1484 strains x 6170 genes
print("Strains x genes:", X.shape)

# 2. PCA to top 100 PCs (as in paper's preprocess_cds default: log + scale then PCA)
print("Running PCA...")
Xlog = np.log1p(X.values)
Xscaled = StandardScaler().fit_transform(Xlog)
pca = PCA(n_components=100, random_state=42)
pcs = pca.fit_transform(Xscaled)
print("PCA done:", pcs.shape, "variance explained:", pca.explained_variance_ratio_.sum().round(3))

# 3. PaCMAP embedding on top 100 PCs
print("Running PaCMAP...")
embedder = pacmap.PaCMAP(n_components=2, n_neighbors=10, MN_ratio=0.5, FP_ratio=2.0, random_state=42)
pacmap_emb = embedder.fit_transform(pcs, init="pca")
pacmap_df = pd.DataFrame(pacmap_emb, columns=['pacmap_1','pacmap_2'])
pacmap_df['strain_sys'] = X.index.values
pacmap_df.to_csv('pacmap_embedding.csv', index=False)
print("PaCMAP embedding saved.")

# 4. Load paper's own UMAP coordinates for comparison
meta = pd.read_csv('yeast_umap/useful_files/umap_metadata_clust50.txt', sep='\t')
meta = meta.rename(columns={'strain.sys':'strain_sys'})
print("Metadata (UMAP coords from paper):", meta.shape)

meta.to_csv('umap_from_paper.csv', index=False)
print("Done.")
