import numpy as np
import pacmap
from sklearn.metrics import roc_auc_score
import warnings, time
warnings.filterwarnings('ignore')

pcs = np.load('pcs.npy')
gold_idx = np.load('gold_genes_idx.npy')
labels = np.load('gold_labels.npy')
iu_i = np.load('gold_iu_i.npy')
iu_j = np.load('gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

print("=== LocalMAP on yeast data: hyperparameter grid ===")
t0 = time.time()
results = []
for nn in [5, 10, 15, 20]:
    for mn in [0.5, 1.0, 2.0]:
        e = pacmap.LocalMAP(n_components=2, n_neighbors=nn, MN_ratio=mn, FP_ratio=2.0, random_state=42, verbose=False)
        Y = e.fit_transform(pcs, init="pca")
        auc = auc_for(Y)
        results.append({'n_neighbors':nn,'MN_ratio':mn,'AUC':auc})
        print(f"nn={nn}, MN={mn} -> AUC={auc:.4f} ({time.time()-t0:.0f}s)")

import pandas as pd
df = pd.DataFrame(results)
df.to_csv('localmap_yeast_grid.csv', index=False)
print(f"\nBest LocalMAP: {df.AUC.max():.4f}  Mean: {df.AUC.mean():.4f}  Worst: {df.AUC.min():.4f}")
print("Recall: UMAP on yeast = 0.71-0.72, original PaCMAP best = 0.684")
