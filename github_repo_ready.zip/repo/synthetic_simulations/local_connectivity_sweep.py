import numpy as np
import umap
from sklearn.metrics import roc_auc_score
import warnings, time, sys, json
warnings.filterwarnings('ignore')

pcs = np.load('pcs.npy')
gold_idx = np.load('gold_genes_idx.npy')
labels = np.load('gold_labels.npy')
iu_i = np.load('gold_iu_i.npy')
iu_j = np.load('gold_iu_j.npy')

def auc_for(emb):
    sub = emb[gold_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(labels, -d)

lc = float(sys.argv[1])
seeds = [1, 7, 13, 42, 55, 77, 99, 123]
t0 = time.time()
aucs = []
for seed in seeds:
    r = umap.UMAP(n_neighbors=15, min_dist=0.05, metric='cosine', local_connectivity=lc, random_state=seed)
    emb = r.fit_transform(pcs)
    aucs.append(auc_for(emb))

print(f"local_connectivity={lc}: mean={np.mean(aucs):.4f} sem={np.std(aucs)/np.sqrt(len(aucs)):.4f} ({time.time()-t0:.0f}s)")
with open(f'lc_batch_{lc}.json','w') as f:
    json.dump(aucs, f)
