import numpy as np
import umap, pacmap
from sim_design_v2 import generate_synthetic_v2
from benchmark_fn import build_pairs_and_labels, auc_for_embedding
import time, warnings, pandas as pd
from scipy.stats import wilcoxon
warnings.filterwarnings('ignore')

def participation_ratio_data(data):
    X = data - data.mean(axis=0)
    cov = np.cov(X.T)
    eigvals = np.linalg.eigvalsh(cov)
    eigvals = eigvals[eigvals > 1e-10]
    return (eigvals.sum()**2) / (eigvals**2).sum()

t0 = time.time()
n_programs_values = [2, 5, 10, 20, 32, 40, 60, 80, 150]
seeds = [1, 7, 13, 42, 55, 77, 99, 123]

rows = []
for npr in n_programs_values:
    prs = []
    for seed in seeds:
        strength = 5.0 * np.sqrt(20.0/npr)
        data, labels, cm = generate_synthetic_v2(
            n_points=1500, n_complexes=150, complex_size_range=(2,8),
            intra_complex_std=0.5, ambient_dim=100,
            n_global_groups=10, global_group_std=3.0,
            n_noise_programs=npr, program_strength=strength, independent_noise_std=0.5,
            seed=seed
        )
        pr = participation_ratio_data(data)
        prs.append(pr)
        in_idx, iu_i, iu_j, same = build_pairs_and_labels(labels)

        r = umap.UMAP(n_neighbors=10, min_dist=0.1, metric='euclidean', random_state=seed)
        emb_u = r.fit_transform(data)
        auc_u = auc_for_embedding(emb_u, in_idx, iu_i, iu_j, same)

        e = pacmap.PaCMAP(n_components=2, n_neighbors=10, MN_ratio=0.5, FP_ratio=2.0, random_state=seed, verbose=False)
        emb_p = e.fit_transform(data, init="pca")
        auc_p = auc_for_embedding(emb_p, in_idx, iu_i, iu_j, same)

        rows.append({'n_programs': npr, 'seed': seed, 'PR': pr, 'UMAP_AUC': auc_u, 'PaCMAP_AUC': auc_p, 'diff': auc_u-auc_p})
    print(f"n_programs={npr} (mean PR={np.mean(prs):.1f}) done ({time.time()-t0:.0f}s)")

df = pd.DataFrame(rows)
df.to_csv('sweep_n_programs_v2_results.csv', index=False)

print("\n=== SUMMARY (8 seeds) ===")
summary = []
for npr in n_programs_values:
    sub = df[df.n_programs==npr]
    mean_diff = sub['diff'].mean()
    sem = sub['diff'].std()/np.sqrt(len(sub))
    mean_pr = sub['PR'].mean()
    stat, p = wilcoxon(sub['UMAP_AUC'], sub['PaCMAP_AUC'])
    summary.append({'n_programs':npr,'mean_PR':mean_pr,'mean_diff':mean_diff,'sem':sem,'p_value':p})
    print(f"n_programs={npr} (PR={mean_pr:.1f}): mean_diff={mean_diff:+.4f}±{sem:.4f}  Wilcoxon p={p:.4f}")

pd.DataFrame(summary).to_csv('sweep_n_programs_v2_summary.csv', index=False)
