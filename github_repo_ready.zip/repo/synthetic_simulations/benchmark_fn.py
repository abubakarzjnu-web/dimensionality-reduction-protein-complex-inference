import numpy as np
from sklearn.metrics import roc_auc_score
from itertools import combinations

def build_pairs_and_labels(labels):
    """From complex labels (-1 = no complex), build all same-complex vs different pairs
    among points that belong to SOME complex (mirrors real gold-standard construction)."""
    in_complex_idx = np.where(labels >= 0)[0]
    n = len(in_complex_idx)
    iu = np.triu_indices(n, k=1)
    li = labels[in_complex_idx]
    same = (li[iu[0]] == li[iu[1]])
    return in_complex_idx, iu[0], iu[1], same

def auc_for_embedding(emb, in_complex_idx, iu_i, iu_j, same_labels):
    sub = emb[in_complex_idx]
    d = np.linalg.norm(sub[iu_i] - sub[iu_j], axis=1)
    return roc_auc_score(same_labels, -d)
