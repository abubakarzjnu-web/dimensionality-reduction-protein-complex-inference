"""
Critical control experiment: does the INDEPENDENT-noise model (v1) also show
a "critical zone" spike in UMAP's favor when swept finely through ITS OWN
signal-to-noise transition region? If YES -> the effect is just generic SNR-
threshold behavior, not specifically about correlated noise. If NO -> the
correlated noise structure is genuinely the key ingredient.
"""
import numpy as np
import umap, pacmap
from sim_design import generate_synthetic
from benchmark_fn import build_pairs_and_labels, auc_for_embedding
import time, warnings, pandas as pd
from scipy.stats import wilcoxon
warnings.filterwarnings('ignore')

t0 = time.time()
# v1's transition zone was found earlier around noise_std 30-50 (AUC 0.77 -> 0.53)
noise_values = [25, 28, 30, 32, 35, 38, 42, 46, 50]
seeds = [1, 7, 13, 42, 55, 77, 99, 123]

rows = []
for nv in noise_values:
    for seed in seeds:
        data, labels, cm = generate_synthetic(
            n_points=1500, n_complexes=150, complex_size_range=(2,8),
            intra_complex_std=0.5, ambient_dim=100, global_noise_std=nv,
            n_global_groups=10, global_group_std=3.0, seed=seed
        )
        in_idx, iu_i, iu_j, same = build_pairs_and_labels(labels)

        r = umap.UMAP(n_neighbors=10, min_dist=0.1, metric='euclidean', random_state=seed)
        emb_u = r.fit_transform(data)
        auc_u = auc_for_embedding(emb_u, in_idx, iu_i, iu_j, same)

        e = pacmap.PaCMAP(n_components=2, n_neighbors=10, MN_ratio=0.5, FP_ratio=2.0, random_state=seed, verbose=False)
        emb_p = e.fit_transform(data, init="pca")
        auc_p = auc_for_embedding(emb_p, in_idx, iu_i, iu_j, same)

        rows.append({'noise_std': nv, 'seed': seed, 'UMAP_AUC': auc_u, 'PaCMAP_AUC': auc_p, 'diff': auc_u-auc_p})
    print(f"noise_std={nv} done ({time.time()-t0:.0f}s)")

df = pd.DataFrame(rows)
df.to_csv('verify3_v1_results.csv', index=False)

print("\n=== SUMMARY (v1, independent noise, own transition zone) ===")
for nv in noise_values:
    sub = df[df.noise_std==nv]
    mean_diff = sub['diff'].mean()
    sem = sub['diff'].std()/np.sqrt(len(sub))
    stat, p = wilcoxon(sub['UMAP_AUC'], sub['PaCMAP_AUC'])
    print(f"noise_std={nv}: mean_diff={mean_diff:+.4f} ± {sem:.4f}   Wilcoxon p={p:.4f}")
