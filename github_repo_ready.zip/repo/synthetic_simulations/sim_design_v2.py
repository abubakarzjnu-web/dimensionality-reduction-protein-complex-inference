"""
More realistic synthetic model: adds CORRELATED biological noise via a
factor model (mimicking real transcriptional programs / regulatory modules
that make many genes co-vary together), instead of independent per-dimension
noise. This is much closer to real gene expression data structure.
"""
import numpy as np

def generate_synthetic_v2(n_points=1500, n_complexes=150, complex_size_range=(2,8),
                           intra_complex_std=0.5, ambient_dim=100,
                           n_global_groups=10, global_group_std=3.0,
                           n_noise_programs=20, program_strength=1.0,
                           independent_noise_std=0.5, seed=42):
    rng = np.random.default_rng(seed)

    # Step 1: global group structure (large-scale organization, e.g. pathways)
    global_centers = rng.normal(0, 10, size=(n_global_groups, ambient_dim))
    point_group = rng.integers(0, n_global_groups, size=n_points)
    data = global_centers[point_group] + rng.normal(0, global_group_std, size=(n_points, ambient_dim))

    # Step 2: form tight complexes (true local signal we want to detect)
    labels = np.full(n_points, -1)
    remaining = list(range(n_points))
    rng.shuffle(remaining)
    complex_id, idx_ptr = 0, 0
    complex_members = {}
    while complex_id < n_complexes and idx_ptr < len(remaining):
        size = rng.integers(complex_size_range[0], complex_size_range[1]+1)
        members = remaining[idx_ptr: idx_ptr+size]
        if len(members) < 2:
            break
        idx_ptr += size
        local_centroid = data[members[0]].copy()
        for m in members:
            data[m] = local_centroid + rng.normal(0, intra_complex_std, size=ambient_dim)
            labels[m] = complex_id
        complex_members[complex_id] = members
        complex_id += 1

    # Step 3: CORRELATED biological noise via factor model
    # n_noise_programs "regulatory programs", each with a random loading pattern
    # across genes; each point gets a random activation of each program.
    loadings = rng.normal(0, 1, size=(n_noise_programs, ambient_dim))
    activations = rng.normal(0, program_strength, size=(n_points, n_noise_programs))
    correlated_noise = activations @ loadings  # (n_points, ambient_dim), correlated across dims

    # Step 4: small independent technical noise on top
    indep_noise = rng.normal(0, independent_noise_std, size=data.shape)

    data_final = data + correlated_noise + indep_noise
    return data_final, labels, complex_members

if __name__ == "__main__":
    data, labels, cm = generate_synthetic_v2()
    print("Data shape:", data.shape, "complexes:", len(cm))
    # sanity: check correlation structure exists (genes should be correlated now)
    corr = np.corrcoef(data.T)
    off_diag = corr[np.triu_indices(len(corr), k=1)]
    print("Mean abs gene-gene correlation:", np.abs(off_diag).mean())
