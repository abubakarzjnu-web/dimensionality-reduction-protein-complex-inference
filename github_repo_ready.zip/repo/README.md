# UMAP vs. PaCMAP for Protein-Complex Inference

Code accompanying the manuscript *"Local Density Adaptivity Explains
System-Dependent Performance Across Five Dimensionality-Reduction Methods in
Protein-Complex Inference."*

## Repository structure

```
yeast_analysis/              Benchmarking on the Kemmeren et al. yeast
                              single-gene deletion compendium (5 methods,
                              gold-standard construction, algorithmic
                              component isolation)
human_perturbseq_analysis/   Benchmarking on K562 and RPE1 genome-scale
                              Perturb-seq data (Replogle et al.) against
                              CORUM, including the high-confidence-only
                              (quality-filtered) RPE1 reanalysis
synthetic_simulations/       Controlled synthetic data generator, the
                              participation-ratio parameter sweep, and the
                              independent-noise control experiment
diagnostic_tool/             dr_method_advisor.py -- standalone tool that
                              estimates the participation ratio of a
                              user-supplied expression matrix and
                              recommends UMAP or PaCMAP
figures/                     Scripts to regenerate all main-text figures
paper/                       LaTeX source, bibliography, and figures for
                              the manuscript
```

## Requirements

**Python 3.10+** (see `requirements.txt` for packages: `umap-learn`,
`pacmap`, `trimap`, `scikit-learn`, `pandas`, `numpy`, `scipy`,
`matplotlib`, `anndata`).

**R** (base R only, plus the `Matrix` package -- almost always
pre-installed) is required for one script,
`yeast_analysis/00_extract_yeast_expression_matrix.R`, which extracts the
yeast expression matrix from its source `.RDS` file. This script does
*not* require the `monocle3` package.

## Data setup

This repository contains analysis code only; raw data are not redistributed.
Before running any script, create a `data/` directory at the repository root
with the following structure and download the corresponding files (direct
links and instructions are in the manuscript's Methods section, "Code and
data availability"):

```
data/
  corum/
    allComplexes.txt              (CORUM complex database)
  costanzo2016/
    Data_File_S12_Protein_complex_standard.xlsx
                                   (from boonelab.ccbr.utoronto.ca/supplement/costanzo2016/;
                                    used only by yeast_analysis/build_expanded_gold.py)
  replogle2022/
    K562_essential_normalized_bulk_01.h5ad
    rpe1_normalized_bulk_01.h5ad
                                   (from the Figshare deposit accompanying
                                    Replogle et al. 2022, Cell)
```

In addition, `yeast_analysis/` scripts expect a local clone of
`github.com/cole-trapnell-lab/yeast_umap` placed *inside* the
`yeast_analysis/` directory itself (i.e. `yeast_analysis/yeast_umap/`), since
`Kemmeren_Consensus.csv` and other yeast gold-standard files are read from
`yeast_umap/useful_files/` relative to the scripts. The yeast expression
matrix (`expression_matrix.csv`) and derived `strain_names.npy` are produced
by `00_extract_yeast_expression_matrix.R` from a `.RDS` file inside that same
cloned repository (see Reproduction order below) and are saved directly into
`yeast_analysis/`, not into `data/`.

## Reproduction order

Scripts within each directory are pipeline steps that read and write
intermediate files (`.npy`, `.csv`, `.json`) in their own working directory.
Run them in this order:

**`yeast_analysis/`**
0. `00_extract_yeast_expression_matrix.R` -- extracts `expression_matrix.csv` from the
   Monocle3 `.RDS` object inside a cloned `yeast_umap/` repository (see Data
   setup above); requires only base R + the `Matrix` package, not `monocle3`
1. `01_compute_pca_and_strain_names.py` -- reads `expression_matrix.csv`, writes
   `pcs.npy` (100-component PCA) and `strain_names.npy`
2. `prep_gold_standard.py` -- uses `strain_names.npy` and the yeast_umap
   consensus file to build gold-standard complex-membership labels
   (`gold_genes_idx.npy`, `gold_labels.npy`, `gold_iu_i.npy`, `gold_iu_j.npy`)
3. `run_pacmap_analysis.py` -- reads `expression_matrix.csv` directly (computes
   its own internal PCA), generates the PaCMAP embedding, and also reads the
   yeast_umap UMAP metadata file to produce `umap_from_paper.csv`
4. `benchmark.py` -- computes the faithful-replication AUC benchmark from the
   two embeddings produced in step 3
5. `test_more_methods.py`, `test_localmap.py` -- benchmark t-SNE/TriMAP and
   LocalMAP using `pcs.npy` and the gold-standard files from step 2
6. `test_umap_components.py`, `verify_local_connectivity.py` -- algorithmic
   component isolation, same inputs as step 5
7. `build_expanded_gold.py` -- optional gold-standard expansion / validation
   check; needs `strain_names.npy`, the yeast_umap consensus file, the
   Costanzo Data File S12, and a downloaded STRING interactions file

**`human_perturbseq_analysis/`** (run the `k562_*` and `rpe1_*` sequences independently)
1. `{k562,rpe1}_build_matrix.py` -- builds the consensus expression matrix from raw `.h5ad`
2. `{k562,rpe1}_pca_and_gold.py` -- PCA + CORUM gold-standard construction
3. `{k562,rpe1}_grid_search.py`, `{k562,rpe1}_seed_check.py` -- benchmarking
4. `rpe1_quality_filter.py` then `rpe1_filtered_pca_and_gold.py` then `rpe1_filtered_benchmark.py` -- high-confidence-only reanalysis

**`synthetic_simulations/`**
- `sim_design_v2.py` and `benchmark_fn.py` are shared modules imported by the sweep scripts
- `participation_ratio_sweep.py`, `local_connectivity_sweep.py`, `independent_noise_control.py` can each be run independently (each generates its own output files)

**`figures/`**
- `make_figures.py` regenerates the main-text figures; run after the corresponding analysis directories have produced their output files

## Diagnostic tool quick start

```python
from diagnostic_tool.dr_method_advisor import recommend_method
import pandas as pd

expr = pd.read_csv("your_expression_matrix.csv", index_col=0)  # perturbations x genes
result = recommend_method(X=expr.values)
print(result.recommendation, result.participation_ratio)
```

See the docstring in `diagnostic_tool/dr_method_advisor.py` for important
notes on preprocessing consistency and quality filtering before use.

## Citation

If you use this code, please cite the accompanying manuscript (citation to
be finalized upon publication).

## License

Code released under the MIT License (see `LICENSE`).
