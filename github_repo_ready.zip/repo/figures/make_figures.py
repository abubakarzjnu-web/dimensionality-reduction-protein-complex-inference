import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})

# ===== Figure 1: 5-method comparison on yeast =====
methods = ['UMAP', 'PaCMAP', 'LocalMAP', 't-SNE', 'TriMAP']
means = [0.715, 0.668, 0.642, 0.640, 0.629]
sems =  [0.004, 0.006, 0.008, 0.011, 0.017]
colors = ['#2b6cb0', '#e07b39', '#e07b39', '#63b3ed', '#e07b39']
# UMAP blue (unique advantage), others orange/grey-ish to group "alternatives"
colors = ['#2b6cb0', '#c05621', '#dd6b20', '#718096', '#a0522d']

fig, ax = plt.subplots(figsize=(6.5,4.5))
bars = ax.bar(methods, means, yerr=sems, capsize=5, color=colors, edgecolor='black', linewidth=0.8)
ax.set_ylabel('Mean AUC (protein-complex recovery)')
ax.set_ylim(0.55, 0.75)
ax.axhline(0.5, color='gray', linestyle=':', linewidth=1, label='Random (AUC=0.5)')
ax.set_title('Five-method comparison on yeast single-gene deletion compendium')
for b, m in zip(bars, means):
    ax.text(b.get_x()+b.get_width()/2, m+0.008, f'{m:.3f}', ha='center', fontsize=9)
plt.tight_layout()
plt.savefig('fig1_yeast_5methods.png', dpi=200)
plt.close()

# ===== Figure 2: K562 vs RPE1 (UMAP vs PaCMAP) =====
fig, ax = plt.subplots(figsize=(6,4.5))
x = np.arange(2)
width = 0.35
umap_vals = [0.712, 0.684]
pacmap_vals = [0.720, 0.716]
umap_err = [0.010, 0.013]
pacmap_err = [0.008, 0.010]

b1 = ax.bar(x-width/2, umap_vals, width, yerr=umap_err, capsize=4, label='UMAP', color='#2b6cb0', edgecolor='black', linewidth=0.8)
b2 = ax.bar(x+width/2, pacmap_vals, width, yerr=pacmap_err, capsize=4, label='PaCMAP', color='#c05621', edgecolor='black', linewidth=0.8)
ax.set_xticks(x)
ax.set_xticklabels(['K562\n(tie)', 'RPE1\n(PaCMAP wins)'])
ax.set_ylabel('Mean AUC (protein-complex recovery)')
ax.set_ylim(0.6, 0.76)
ax.set_title('UMAP vs PaCMAP across two human Perturb-seq datasets')
ax.legend()
plt.tight_layout()
plt.savefig('fig2_human_datasets.png', dpi=200)
plt.close()

# ===== Figure 3: local_connectivity mechanism =====
lc_vals = [1.0, 5.0, 15.0, 30.0]
lc_means = [0.7044, 0.7026, 0.6743, 0.6743]
lc_sems = [0.0018, 0.0027, 0.0028, 0.0028]

fig, ax = plt.subplots(figsize=(6.5,4.5))
ax.errorbar(lc_vals, lc_means, yerr=lc_sems, marker='o', markersize=8, capsize=4, color='#2b6cb0', linewidth=2)
ax.axhline(0.668, color='#c05621', linestyle='--', linewidth=1.5, label='PaCMAP reference (0.668)')
ax.set_xlabel('UMAP local_connectivity parameter')
ax.set_ylabel('Mean AUC')
ax.set_title("Suppressing UMAP's local-density adaptivity\nreduces performance to PaCMAP's level")
ax.legend()
plt.tight_layout()
plt.savefig('fig3_local_connectivity.png', dpi=200)
plt.close()

# ===== Figure 4: participation ratio synthetic curve with real data =====
import pandas as pd
df = pd.read_csv('../synthetic_simulations/sweep_n_programs_v2_summary.csv')

fig, ax = plt.subplots(figsize=(7.5,5))
ax.errorbar(df['mean_PR'], df['mean_diff'], yerr=df['sem'], marker='o', capsize=4,
            color='#2b6cb0', linewidth=2, label='Synthetic simulation (UMAP $-$ PaCMAP AUC)')
ax.axhline(0, color='gray', linestyle='--', linewidth=1)
sig = df['p_value'] < 0.05
ax.scatter(df.loc[sig,'mean_PR'], df.loc[sig,'mean_diff'], color='red', zorder=5, s=70, label='p < 0.05')

real_points = {'Yeast': 8.0, 'K562': 35.8, 'RPE1': 25.0}
real_colors = {'Yeast': 'green', 'K562': 'purple', 'RPE1': 'darkorange'}
ymin, ymax = ax.get_ylim()
for name, pr in real_points.items():
    ax.axvline(pr, color=real_colors[name], linestyle=':', alpha=0.8, linewidth=1.5)
    ax.text(pr, ymax*0.9, name, rotation=90, fontsize=10, ha='right', color=real_colors[name], fontweight='bold')

ax.set_xlabel('Participation ratio (effective number of correlated background programs)')
ax.set_ylabel('AUC(UMAP) $-$ AUC(PaCMAP)  [synthetic model]')
ax.set_title('UMAP advantage as a function of background correlation structure,\nwith real-dataset participation ratios marked')
ax.legend(loc='upper right')
plt.tight_layout()
plt.savefig('fig4_participation_ratio.png', dpi=200)
plt.close()

print("All 4 figures saved.")
